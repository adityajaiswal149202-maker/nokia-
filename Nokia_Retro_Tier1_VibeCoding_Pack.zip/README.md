# Nokia Retro — Tier 1 Vibe Coding Pack

This pack is the source-of-truth starter brief for building **Tier 1 only**: a polished retro Nokia-inspired interactive phone experience. It is intentionally scoped to the simulated phone shell, screen, permanent keypad, navigation, sound feedback, menus, theme customization, and a small number of playable games.

## Start here
1. Read `docs/PRODUCT_BRIEF.md`.
2. Read `docs/TIER_1_SCOPE.md` and `docs/UX_SPEC.md`.
3. Give the AI coding agent `VIBE_CODING_MASTER_PROMPT.md` and attach this ZIP / project folder as its reference.
4. Build in small milestones. Do not let the agent start Tier 2 or Tier 3 features.

## Reference assets
- `assets/reference_images/nokia_phone_reference.jpg` — user's preferred phone visual reference.
- `assets/reference_images/retro_games_list_reference.jpg` — future game library inspiration/reference; not a commitment to implement all titles in Tier 1.
- `assets/ui/` — starter SVG icons and a visual palette.

## Product principle
Make a convincing, delightful retro phone simulation. It is **not** a real dialer, SMS app, launcher, or browser in Tier 1. Do not request sensitive permissions or pretend simulated functions are real.

## Suggested stack
Android-first Flutter app. Use Flutter stable, Dart, local assets, and local state. Use clean separation between UI, navigation state, game logic, audio, and settings. No backend required.

## Documentation
- `docs/PRODUCT_BRIEF.md` — vision and product positioning.
- `docs/TIER_1_SCOPE.md` — in-scope and out-of-scope requirements.
- `docs/UX_SPEC.md` — screen and interaction behavior.
- `docs/VISUAL_DESIGN.md` — visual direction, colors, typography, assets.
- `docs/TECHNICAL_GUIDANCE.md` — suggested architecture, quality, and accessibility.
- `docs/MILESTONES.md` — build sequence and acceptance checks.
- `docs/ASSET_NOTES.md` — image/assets and licensing guidance.
- `VIBE_CODING_MASTER_PROMPT.md` — copy/paste prompt for your coding agent.
