# Product Brief

## Working name
**Nokia Retro** (working title; use no official Nokia logo or trademark artwork unless user later confirms licensing).

## Product concept
A standalone Android app that recreates the tactile, menu-driven feeling of a classic candy-bar phone on a modern touchscreen. The phone body, LCD-like screen, keypad, pixel typography, menu movement, button feedback, and nostalgic sounds should feel cohesive and convincing.

The app is a simulator / nostalgic experience, not a replacement for Android's home screen during Tier 1.

## Core promise
**A classic phone experience with a permanently visible, interactive keypad.**

## Audience
- People nostalgic for classic mobile phones.
- Retro-game fans.
- Users who enjoy playful, tactile UI and minimalist experiences.

## Product principles
1. The keypad is always visible in Classic mode.
2. Every visible control must work, with no decorative dead buttons.
3. Feedback is immediate: visual key depression, optional click sound, and haptics.
4. Keep menus simple, readable, and predictable.
5. The screen and keypad should look like parts of one physical device.
6. No real communication or privacy-sensitive capabilities in Tier 1.
7. Games should be honestly playable—not placeholder menu items.
8. Build a polished small scope before adding features.

## Tier 1 success
A user can launch the app, enjoy a convincing Nokia-inspired home screen, navigate its menus entirely with the on-screen keypad, change a few themes/settings, and play a small set of mini-games using the keypad.
