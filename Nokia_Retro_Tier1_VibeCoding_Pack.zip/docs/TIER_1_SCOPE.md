# Tier 1 Scope

## In scope
### Phone simulator shell
- Device silhouette and screen/keypad composition inspired by the supplied reference image.
- Responsive layout for different Android aspect ratios; don't assume a specific phone size.
- LCD-style display with a configurable green/grey tint.
- Standby screen with digital clock, date, battery-style indicator, and simulated signal bars.
- The battery and signal indicators are explicitly simulated; don't read real system data.
- Retro boot / startup animation that can be skipped.
- Optional immersive presentation; provide a way to exit/return safely.

### Keypad
- Always visible in **Classic mode**.
- Number keys 0–9, star, hash, directional controls, center/select, C/back, green call-style key, red end-style key.
- Tier 1 uses call/end keys as simulator controls only: green can act as contextual confirm/shortcut; red acts as exit/back-to-home. No actual calls.
- Every key supports touch, pressed-state animation, sound setting, and optional haptic feedback.
- Use tap input; do not require multi-touch.

### Navigation and menu
- Menu opens from center/select or contextual soft key.
- Arrow keys move focus; center selects; C/back returns; red/end returns home or exits current activity with a predictable confirmation if needed.
- Menu items: Games, Tools, Settings, Themes, About.
- Tools in Tier 1: Calculator, Clock/Stopwatch (choose simple implementation), Notes (local-only simple note) — build only if milestones allow. Prioritize core shell first.
- Keep menu list short and pixel-like. Focus indicator must be clear.

### Games
Tier 1 target: **3–5 complete, simple, original mini-games**. Prioritize:
1. Snake (primary, polished)
2. Memory / Pairs
3. Block Breaker or a simple puzzle game (choose one)
4. Optional fourth/fifth only after quality checks

All games are original implementations inspired by retro mobile gameplay. Don't copy original proprietary game code, assets, names, or music. The Games menu can include only implemented games at launch. A future 50-game collection is documented as a long-term idea, not Tier 1 requirement.

Controls should map to keypad arrows, center/select, and number keys where appropriate. The keypad remains visible during gameplay in Classic mode. Include pause, restart, game-over, score, and a return-to-games-menu flow.

### Sounds / feedback
- Enable/disable key sounds, menu sounds, game sounds, and vibration separately.
- Use original synthesized/created short sounds or properly licensed sound assets.
- Keep volume modest; provide silent mode and no sound auto-play outside the app.
- Haptics optional and controlled by user.

### Customization
Tier 1 customization:
- 2–3 LCD color presets (e.g. pale green, grey, amber).
- 2–3 body/keypad palettes (e.g. charcoal, silver, blue accent).
- Sound toggle and haptics toggle.
- Animation reduced-motion toggle.
- Reset theme/settings.

### Quality
- Works offline.
- No account, backend, analytics, ads, or network dependency.
- App state/settings saved locally.
- No sensitive permissions.
- Avoid using official Nokia logo or proprietary visual assets; use a generic retro candy-bar phone aesthetic.

## Out of scope (explicitly NOT Tier 1)
- Default Android launcher / home replacement.
- Real cellular calling, call management, default dialer role.
- Real SMS/MMS/RCS, default SMS role.
- Contacts access, phone permissions.
- Browser or ad-blocking engine.
- All 50 games or original commercial game ROMs/APKs.
- Online leaderboard, multiplayer, cloud sync, login, account.
- Full emulator for Java/Symbian/N-Gage.
- 3D/large commercial game recreations.
- System-level controls, real signal/battery reading.
- Widgets, notifications, or modifying Android system UI.
