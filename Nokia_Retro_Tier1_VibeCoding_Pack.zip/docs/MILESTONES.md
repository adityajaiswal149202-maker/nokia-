# Milestones & Acceptance Criteria

## M0 — Project foundation
- Create Android-first Flutter app.
- App launches without errors.
- Add project structure and asset paths.
- Establish responsive portrait layout.
**Acceptance:** Android build runs on emulator/device; README explains run/build commands.

## M1 — Phone shell and standby
- Draw phone shell, LCD, keypad, soft keys.
- Add standby clock/date and simulated status indicators.
- Key press animation.
- Safe exit/back behavior.
**Acceptance:** shell looks cohesive at small and large portrait screen sizes; keypad visible and tappable.

## M2 — Navigation and menus
- Main menu: Games, Tools, Settings, Themes, About.
- Unified keypad event dispatcher.
- Touch and keypad both navigate/select.
- Back/end key behavior.
**Acceptance:** navigate through menus without needing Android touch controls except optional direct tapping; no dead keys.

## M3 — Sounds and feedback
- Original short key/menu sounds.
- Haptics toggle.
- Sound settings, master mute.
**Acceptance:** settings work; no sound if muted; sound/haptic feedback follows key presses.

## M4 — Theme settings
- LCD presets, body/key colors, preview/apply.
- Persist settings.
**Acceptance:** applying a theme updates the entire shell and survives restart.

## M5 — Snake
- Complete playable game with score, food, pause/restart, game over, best score.
- Keypad arrows control it.
**Acceptance:** all game states work, no immediate reverse, pause works, leaving game cancels timer.

## M6 — Memory Pairs
- Complete game with cursor, flip, match, win, restart.
**Acceptance:** keypad-only play is possible and game is stable.

## M7 — Third mini-game (scope gate)
Choose Block Breaker or a simple puzzle based on time/quality.
**Acceptance:** finish M5/M6 polish before starting M7.

## M8 — Polish
- Startup animation skip.
- Reduced motion setting.
- Accessibility labels.
- Visual and device-size QA.
**Acceptance:** no known blocking crashes, all in-scope controls work, final build and documented limitations.

## Definition of done for Tier 1
- All milestones M0–M6 completed.
- M7 is optional; if implemented, fully playable.
- No placeholder menu entries for unimplemented games.
- App remains offline and asks for no sensitive permissions.
