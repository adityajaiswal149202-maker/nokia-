# Asset Notes & Licensing

## Included
- Two user-provided visual reference photos in `assets/reference_images/`.
- Starter SVG interface assets in `assets/ui/`.

## How to use reference photos
Treat photos as visual references for proportions, overall layout, physical keypad placement, and retro screen mood. Do not directly trace or copy copyrighted logos, distinctive branded artwork, or commercial game assets into the app.

## Branding
Use a temporary original name/wordmark such as **RETRO PHONE** or **NOKIA RETRO (working title)** in prototypes. If this becomes a public app, evaluate trademark use and naming with appropriate legal advice. Do not use an official Nokia logo unless permission/licensing is obtained.

## Games
Implement original mini-game code and original/simple graphics. Do not bundle game ROMs, APKs, original proprietary game sprites, music, or ringtones without permission/licensing.

## Fonts and audio
Use open-license fonts and audio only. Keep license and attribution files alongside each asset. Prefer original synthesized retro tones and simple UI sounds.

## Asset inventory
- `reference_images/nokia_phone_reference.jpg`
- `reference_images/retro_games_list_reference.jpg`
- `ui/lcd_palette.svg`
- `ui/keypad_layout.svg`
- `ui/retro_menu_icon.svg`

The SVGs are starter visualization assets, not production-ready artwork. The coding agent may improve them while preserving the design direction.
