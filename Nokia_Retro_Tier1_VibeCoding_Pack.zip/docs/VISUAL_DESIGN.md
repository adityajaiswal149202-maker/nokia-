# Visual Design Direction

## References
Use the provided images as inspiration, not as exact assets:
- `assets/reference_images/nokia_phone_reference.jpg`: form factor, physical keypad proportions, classic display placement.
- `assets/reference_images/retro_games_list_reference.jpg`: long-term retro game catalog idea. Tier 1 does not implement all games shown.

## Aesthetic
- Classic candy-bar phone silhouette with rounded top and lower keypad section.
- Small monochrome LCD with a green-tinted background, dark pixel-like text, simple pixel icons.
- Physical-button visual treatment: rounded/oval keys, highlights, shadows, subtle pressed movement.
- Avoid modern glassmorphism, gradients everywhere, large cards, or Material-looking UI inside the simulated phone.
- Outside the simulated device, Android app chrome should be minimal.

## Starter palette (approximate; tune against reference)
- LCD pale green: `#C7D6A2`
- LCD darker green: `#A9BC83`
- LCD text: `#24351D`
- LCD dark: `#34452B`
- Shell charcoal: `#202329`
- Key silver: `#C8CBD0`
- Key highlight: `#F0F1F3`
- Key shadow: `#727780`
- Accent green key: `#65A76C`
- Accent red key: `#C9585D`
- Amber LCD preset: `#D8C58C`
- Grey LCD preset: `#C5C8C5`

## Typography
- Prefer a legible pixel/bitmap-inspired font, but ensure fallback text remains readable.
- Use bundled fonts only if their license allows redistribution. Keep font license files in the project if a font is included.
- Use monospaced fallback for numbers, clock, scores and menu lists.
- Pixel font should not be used for long descriptions or settings if it hurts readability.

## Layout
- Phone silhouette should fit vertically on common Android portrait displays.
- Screen should occupy roughly upper 30–40% of device body; keypad section below.
- Use a responsive composition with safe area, adaptive spacing, and proportional scaling.
- The display and keypad are parts of one coherent device—not independent floating components.
- Key sizes should be large enough for reliable touch; target ~44–48 dp minimum touch dimensions when practical, even if the visual key is smaller.

## Motion
- Key press: subtle down movement and shadow reduction.
- Menu selection: simple LCD redraw/slide or blink, short and restrained.
- Boot: optional short scanline/blink effect; provide skip and reduced-motion option.
- Game movement: clear frame cadence, no stutter.

## Accessibility and usability
- Ensure adequate contrast on LCD.
- Support Android text scaling where reasonable; for pixel UI, don't let text clip.
- Provide semantics/labels for buttons.
- Avoid color-only feedback; focus and pressed states should be visible.
- Optional haptic feedback.
