# Technical Guidance for Vibe Coding

## Suggested platform
**Flutter + Dart, Android-first.** This is a good fit for a custom illustrated phone shell, precise touch controls, simple game loops, responsive layouts, local preferences, and rapid iteration. If the coding agent proposes a different stack, it must explain the trade-offs before changing.

## Architecture (keep simple but separated)
- `app/`: app bootstrap, lifecycle, theme, routing.
- `phone_shell/`: device body, LCD screen, keypad, soft-key area.
- `navigation/`: menu state and key event routing.
- `screens/`: standby, menu, settings, theme preview, about.
- `games/`: game interface and isolated game logic (Snake, Memory, third game).
- `audio/`: sound service and sound settings.
- `settings/`: local persistence for themes, audio, haptics, reduced motion, scores.
- `assets/`: SVG/PNG, audio, fonts, licenses.
- `widgets/`: reusable buttons, LCD text, icons.

Do not over-engineer with complex state-management packages for a small Tier 1 app. Choose a simple, maintainable state approach and document it. Avoid monolithic files.

## Key input
Create a single input dispatcher that converts each virtual keypad press into an action based on current screen/state. The same key should not have duplicated competing handlers. Game screens register their mappings while active; menu and standby use default mapping. Make touch and key handling share the same action pathway.

## Game logic
- Keep game state separate from rendering.
- Use deterministic, testable rules where possible.
- Avoid uncontrolled timers; pause/dispose timers on lifecycle changes.
- Use a frame/tick loop appropriate for each simple game and cancel it when leaving.
- Keep score persistence local.

## Audio
- Short, original sound assets or synthesized tones only.
- Provide separate switches and a master mute.
- Dispose audio resources correctly.
- No sound before user interaction / no unexpected background playback.
- Don't bundle copyrighted Nokia ringtones or game music unless license permits.

## Persistence
Store settings and high scores locally. No account or network needed.
Potential values: selected theme, sound toggles, haptics, reduced motion, game best scores.

## Quality checks
- App builds and runs on Android.
- Portrait-first layout and at least one smaller-screen test.
- Every keypad key has a documented action in each relevant screen.
- Back navigation works consistently.
- No button is inert.
- No game continues in background.
- No crashes on rapid input, repeated navigation, pause/resume.
- Settings survive app restart.
- Offline works.
- No sensitive permissions requested.

## AI coding agent behavior
- First inspect the existing project and this brief.
- Produce a plan and file structure before coding.
- Build one milestone at a time.
- Run available tests/build after each milestone.
- Do not silently add out-of-scope features.
- Ask before making architecture or scope changes.
- Use placeholder assets only when clearly labeled and replace them before claiming completion.
