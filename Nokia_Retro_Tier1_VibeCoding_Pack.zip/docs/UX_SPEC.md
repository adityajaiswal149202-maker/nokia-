# UX & Interaction Specification

## App entry
- Show a brief retro boot animation (logo text should be original, e.g. `RETRO PHONE`), with skip/tap-to-continue.
- Land on standby/home.
- A safe, obvious way to exit the simulator or return to Android must exist (Android back handling and/or visible exit confirmation).

## Standby screen
LCD area includes:
- Time (12/24-hour preference optional; default device locale).
- Date.
- Simulated battery bars and signal bars, with a small `SIM`/`DEMO` label or About disclosure so no one mistakes these for actual connectivity.
- Menu soft-key hint and contextual left/right soft-key labels.
- Optional short idle animation, disabled when reduced motion is enabled.

## Input model
- Directional Up/Down: move list focus; in games map to movement.
- Left/Right: contextual navigation or game movement.
- Center/select: select/confirm; on standby open main menu.
- C/back: back one level; in text entry clear/backspace.
- Green call-style key: contextual shortcut/confirm, simulator-only.
- Red end-style key: cancel/return home; never terminate Android process abruptly.
- Number keys: shortcuts in menus if numbered; game actions as defined.
- Star/hash: context-specific action or show a small on-screen explanation; ensure no dead button.
- A touch on a button should visually depress (scale/offset/shadow), then release smoothly.

## Main menu
Suggested list:
- Games
- Tools
- Settings
- Themes
- About

Use pixel-ish icons or simple monochrome glyphs, but avoid visual clutter. Menu should support keypad navigation and touch selection. Focus and selection must be consistent.

## Games menu
Only show fully implemented games. Each game item includes a short description and control hints. Selecting a game transitions to its game screen. Provide:
- Start / pause
- Restart
- Score / best score (best stored locally)
- Game over state
- Back to games list
- Sound toggle available in settings

### Snake
- Grid-based, clear pixel visuals.
- Arrow buttons control direction; don't allow immediate reversal into self.
- Food placement never overlaps snake.
- Score increases when food eaten.
- Speed increases gradually with score, within fair limits.
- Pause, restart, game over.
- Prevent gameplay from continuing while app is backgrounded.
- Avoid input lag; accept directional input between frames and buffer one upcoming direction.

### Memory / Pairs
- Grid of pairs with simple symbols.
- Use keypad arrows to move selection, center to flip.
- Match feedback, move counter, timer optional.
- Win state, restart, return.

### Third game
Select either Block Breaker (paddle left/right using arrows; center launch) or a simple original puzzle. Do not implement both before first two games are stable.

## Settings
- Sound master toggle.
- Key sounds toggle.
- Game sounds toggle.
- Haptics toggle.
- Reduced motion toggle.
- LCD preset selection.
- Body palette selection.
- Reset to defaults.

## Themes
Theme preview should show phone shell, LCD, keypad, and screen text together. Apply theme instantly; persist selection.

## Notes on layout modes
- **Classic mode (default):** phone display and keypad visible together; keypad remains visible while menus and games are active.
- For very small screens, use a responsive scale and safe scrolling. Do not introduce a second mode in Tier 1 unless the keypad becomes unusably small. If needed, consider a future Expanded Display mode, but it is not required now.

## Navigation diagram
```mermaid
flowchart TD
    A[Boot] --> B[Standby]
    B --> C[Main Menu]
    C --> D[Games]
    C --> E[Tools]
    C --> F[Settings]
    C --> G[Themes]
    C --> H[About]
    D --> I[Snake]
    D --> J[Memory Pairs]
    D --> K[Third Game]
    I --> D
    J --> D
    K --> D
    E --> B
    F --> C
    G --> C
    H --> C
```
