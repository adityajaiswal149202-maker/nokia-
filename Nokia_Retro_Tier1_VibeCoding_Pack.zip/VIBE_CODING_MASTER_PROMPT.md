# MASTER PROMPT — Build Nokia Retro Tier 1

You are a senior Flutter Android developer, interaction designer, and QA engineer. Build the Tier 1 MVP of **Nokia Retro**, a standalone nostalgic phone simulator. The project brief, scope, UX, design, technical guidance, milestones, and user-provided references are included in this project pack. Treat those documents as the source of truth.

## Product vision
Create a convincing classic candy-bar phone experience on a modern Android screen. It must have a cohesive phone body, a small LCD-style display, pixel-inspired menus, a permanently visible interactive keypad in Classic mode, tactile key feedback, retro sounds, settings/themes, and a small set of genuinely playable original mini-games.

This is a simulator, not a real phone service in Tier 1.

## Scope lock — Tier 1 only
Implement:
1. Responsive phone shell inspired by the included reference image.
2. LCD standby screen with clock/date and **simulated** battery/signal indicators.
3. Always-visible touch keypad: 0–9, `*`, `#`, directional arrows, center/select, C/back, green call-style, red end-style keys.
4. Boot/standby/main-menu navigation and predictable back behavior.
5. Main menu: Games, Tools, Settings, Themes, About. Tools may be limited to calculator/clock/stopwatch/notes; prioritize shell first and only add tools if the milestones permit.
6. Key press visual animation, optional original click/menu audio, optional haptics.
7. Settings: sound, key sounds, game sounds, haptics, reduced motion.
8. Theme presets: 2–3 LCD tints and 2–3 body/key color themes; theme preview and local persistence.
9. Snake fully playable and polished using the virtual keypad.
10. Memory/Pairs fully playable using the virtual keypad.
11. Optionally one third mini-game after the first two are polished.
12. Local persistence for settings and best scores.
13. Offline operation, no login/backend/network, no sensitive permissions.

## Explicitly do NOT implement now
- Real calling, dialer role, contacts permissions, call UI.
- Real SMS/MMS/RCS, SMS role, message permissions.
- Web browser, ad blocking.
- Android launcher replacement.
- Full Java/Symbian/N-Gage emulator.
- All 50 games, commercial games, ROM/APK loading, online features.
- 3D racing/action/sports games.
- Cloud sync, accounts, ads, analytics.
Do not add any of these as hidden unfinished buttons. Keep Tier 1 focused.

## Visual direction
Use the user's reference photos as inspiration. The phone body should be recognizable as a retro candy-bar device: screen above, speaker/branding area, soft-key/navigation controls, numeric keypad below. The screen should look like a pale green/grey monochrome LCD with dark pixel-inspired text/icons. Keys should have depth, highlights and shadows; pressing a key should subtly move it and reduce its shadow. Avoid a generic Material UI inside the phone simulation. Use a neutral outer app canvas and keep the device centered.

Starter colors (adjust with visual judgment):
- LCD pale green `#C7D6A2`
- LCD darker green `#A9BC83`
- LCD text `#24351D`
- Shell charcoal `#202329`
- Key silver `#C8CBD0`
- Key highlight `#F0F1F3`
- Key shadow `#727780`
- green key `#65A76C`
- red key `#C9585D`
- amber LCD `#D8C58C`
- grey LCD `#C5C8C5`

## Interaction rules
- A single keypad event dispatcher routes inputs based on current screen.
- Menu: up/down changes focused item; center selects; C returns one level; red/end returns standby safely.
- Standby: center opens menu; soft keys are contextual and visible.
- In games: arrows and game-specific keys are mapped; center pauses/starts; C returns; red/end requests exit/back.
- Touch on LCD menu items may select them too, but keypad operation must work end-to-end.
- Every visible key must have a meaningful action in each context or a clear contextual explanation; never leave dead buttons.
- Buttons need accessible labels/semantics.
- The keypad must stay visible in Classic mode, including when games are active. Design game content to fit the display area.
- Handle Android back and app lifecycle. Pause games when backgrounded. Dispose timers/audio properly.

## Engineering requirements
- Use Flutter stable and Dart unless you have a compelling reason; explain before switching stack.
- Keep components and logic separated. Do not create one huge widget/file.
- Keep game rules separate from rendering.
- Use a maintainable state approach without unnecessary complexity.
- Persist settings and best scores locally.
- No sensitive permissions; no internet requirement.
- Include tests for game logic and input/navigation behavior where feasible.
- Use licensed assets only. Do not use Nokia logos, copied game assets, or copyrighted ringtone/music.
- Keep a TODO list, but never expose unimplemented features as working UI.
- If you cannot verify a build, say so clearly rather than claiming it passes.

## Build workflow — do this sequentially
**Before coding:** inspect pack, summarize scope, propose project folder structure, list assumptions, and produce an implementation plan with milestones. Do not start writing the whole app in one pass.

Then implement:
- M0 project foundation
- M1 phone shell/standby
- M2 keypad/navigation
- M3 sounds/feedback
- M4 themes/settings
- M5 Snake
- M6 Memory Pairs
- M7 optional third game only if M0–M6 are complete and stable
- M8 polish/QA

At the end of each milestone:
1. Summarize changed files and behavior.
2. Run relevant tests/build checks.
3. Report errors and unresolved items.
4. Give manual test steps.
5. Ask for approval before moving to the next milestone unless the user explicitly requests autonomous implementation.

## First task now
Do not build everything immediately. Read the documents and reference images. Respond with:
- Your understanding of Tier 1.
- A proposed Flutter project structure.
- A milestone-by-milestone plan.
- Any key assumptions or risks.
Then wait for approval to begin M0/M1.
